import os
from typing import List, Union

import deepsnap
import numpy as np
import pandas as pd
import torch
from deepsnap.graph import Graph
from sklearn.preprocessing import MinMaxScaler, OrdinalEncoder

from graphgym.config import cfg
from graphgym.register import register_loader


def load_single_dataset(dataset_dir: str, edge_feat_dir: str, node_feat_dir: str) -> Graph:
    df_trans = pd.read_csv(dataset_dir,sep=',', index_col=None)
    df_trans.columns = ['index',"source","target","ts","label","idx"]
    num_nodes = len(pd.unique(df_trans[["source","target"]].to_numpy().ravel()))

    df_trans["ts"] = df_trans["ts"].astype(np.int32).astype(np.float32)
    assert not np.any(pd.isna(df_trans).values)

    node_indices = np.sort(pd.unique(df_trans[['source', 'target']].to_numpy().ravel()))
    enc = OrdinalEncoder(categories=[node_indices, node_indices])
    raw_edges = df_trans[['source', 'target']].values
    edge_index = enc.fit_transform(raw_edges).transpose()
    edge_index = torch.LongTensor(edge_index)
    edge_feature = torch.tensor(np.load(edge_feat_dir).astype(np.float32))

    # np.save(edge_feat_dir,edge_feature.numpy())
    assert edge_feature.shape[0] == len(df_trans)
    node_feature = torch.tensor(np.load(node_feat_dir))
    edge_time = torch.LongTensor(df_trans["ts"].values)

    graph = Graph(
        node_feature=node_feature,
        edge_feature=edge_feature,
        edge_index=edge_index,
        edge_time=edge_time,
        directed=True
    )

    return graph


def load_generic(dataset_dir: str,
                 edge_feat_dir: str,
                 node_feat_dir: str,
                 snapshot: bool = True,
                 snapshot_freq: str = None
                 )-> Union[deepsnap.graph.Graph,
                            List[deepsnap.graph.Graph]]:
    g_all = load_single_dataset(dataset_dir,edge_feat_dir,node_feat_dir)
    if not snapshot:
        return g_all

    if snapshot_freq.upper() not in ['D', 'W', 'M']:
        # formate: '1200000s'
        # assume split by seconds (timestamp) as in EvolveGCN paper.
        freq = int(snapshot_freq.strip('s'))
        snapshot_list = split_by_seconds(g_all, freq)
    else:
        print(f"wrong snapshot_freq")
        exit(-1)
        # snapshot_list = make_graph_snapshot(g_all, snapshot_freq)

    num_nodes = g_all.edge_index.max() + 1
    for g_snapshot in snapshot_list:
        g_snapshot.node_states = [0 for _ in range(cfg.gnn.layers_mp)]
        g_snapshot.node_cells = [0 for _ in range(cfg.gnn.layers_mp)]
        g_snapshot.node_degree_existing = torch.zeros(num_nodes)

    # check snapshots ordering.
    prev_end = -1
    for g in snapshot_list:
        start, end = torch.min(g.edge_time), torch.max(g.edge_time)
        assert prev_end < start <= end
        prev_end = end

    return snapshot_list


def make_graph_snapshot(g_all: Graph, snapshot_freq: str) -> List[Graph]:
    t = g_all.edge_time.numpy().astype(np.int64)
    snapshot_freq = snapshot_freq.upper()

    period_split = pd.DataFrame(
        {'Timestamp': t,
         'TransactionTime': pd.to_datetime(t, unit='s')},
        index=range(len(g_all.edge_time)))

    freq_map = {'D': '%j',  # day of year.
                'W': '%W',  # week of year.
                'M': '%m'  # month of year.
                }

    period_split['Year'] = period_split['TransactionTime'].dt.strftime(
        '%Y').astype(int)

    period_split['SubYearFlag'] = period_split['TransactionTime'].dt.strftime(
        freq_map[snapshot_freq]).astype(int)

    period2id = period_split.groupby(['Year', 'SubYearFlag']).indices

    periods = sorted(list(period2id.keys()))
    snapshot_list = list()

    for p in periods:
        # unique IDs of edges in this period.
        period_members = period2id[p]
        assert np.all(period_members == np.unique(period_members))

        g_incr = Graph(
            node_feature=g_all.node_feature,
            edge_feature=g_all.edge_feature[period_members, :],
            edge_index=g_all.edge_index[:, period_members],
            edge_time=g_all.edge_time[period_members],
            directed=g_all.directed
        )
        snapshot_list.append(g_incr)

    snapshot_list.sort(key=lambda x: torch.min(x.edge_time))

    return snapshot_list


def split_by_seconds(g_all, freq_sec: int):
    # Split the entire graph into snapshots.
    split_criterion = g_all.edge_time // freq_sec
    groups = torch.sort(torch.unique(split_criterion))[0]
    snapshot_list = list()
    for t in groups:
        period_members = (split_criterion == t)
        g_incr = Graph(
            node_feature=g_all.node_feature,
            edge_feature=g_all.edge_feature[period_members, :],
            edge_index=g_all.edge_index[:, period_members],
            edge_time=g_all.edge_time[period_members],
            directed=g_all.directed
        )
        snapshot_list.append(g_incr)
    return snapshot_list






def load_wrf_dataset(format,name,dataset_dir):
    if format == "wrf":
        edge_file = "ml_{}.csv".format(name)
        egde_feat_file = "ml_{}.npy".format(name)
        node_feat_file = "ml_{}_node.npy".format(name)
        graphs = load_generic(os.path.join(dataset_dir, edge_file),
                              os.path.join(dataset_dir, egde_feat_file),
                              os.path.join(dataset_dir,node_feat_file),
                              snapshot=cfg.transaction.snapshot,
                              snapshot_freq=cfg.transaction.snapshot_freq)
        return graphs



register_loader('roland_wrf',load_wrf_dataset)

if __name__ == '__main__':
    # Example usage.
    # TODO: change the directory to your sample dataset.
    dataset_dir = '/home/wtx/workspace/python_project/roland-master/roland_public_data'    # a list of homogenous monthly transaction graphs.
    for name in ["wikipedia", "reddit", "Flights"]:
        edge_file = "ml_{}.csv".format(name)
        egde_feat_file = "ml_{}.npy".format(name)
        node_feat_file = "ml_{}_node.npy".format(name)
        # if name == "Flights":
        #     edge_feature = np.load(os.path.join(dataset_dir, egde_feat_file))
        #     new_edge_feature = np.random.rand(edge_feature.shape[0],172)
        #     np.save(os.path.join(dataset_dir, egde_feat_file),new_edge_feature)
        #     print("success")
        snapshot_freq = "100000s" if name != "Flights" else "7s"
        graphs = load_generic(os.path.join(dataset_dir, edge_file),
                              os.path.join(dataset_dir, egde_feat_file),
                              os.path.join(dataset_dir, node_feat_file),
                              snapshot=True,
                              snapshot_freq=snapshot_freq)